const express = require("express")
const Usuario = require("../db/models/usuario")

const router = express.Router()

router.post('/auth', async (req, res) => {
  const {email, senha} = req.body
  try {
    let user = await Usuario.findOne({where: {email}})

    if (!user) {
      return res.redirect('/')
    } else if (user.senha == senha){
      return res.redirect('/dashboard')
    }
  } catch (error) {
    console.error(error);
  }

})

router.post('/addUser', async (req, res) => {
  const {nome, email, telefone, cpf, status, categoria} = req.body
  await Usuario.create({
    nome,
    email,
    telefone,
    cpf,
    status,
    categoria
  })
  return res.redirect('/dashboard')

})


module.exports = router