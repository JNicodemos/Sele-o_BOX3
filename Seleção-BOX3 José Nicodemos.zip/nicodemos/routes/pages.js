const express = require("express")
const Usuario = require("../db/models/usuario")

const router = express.Router()

router.get('/', (req, res) => {
  res.render('index')
})

router.get('/dashboard', async (req, res) => {
  const [allUsers, allClients, allEmployees] = await Promise.all([
    Usuario.count(),
    Usuario.count({where: {categoria: 'Cliente'}}),
    Usuario.count({where: {categoria: 'Funcionário'}})
  ])

  res.render('dashboard', {allClients, allEmployees, allUsers})
})

router.get('/usuarios', async (req, res) => {
  const usuarios = await Usuario.findAll()
  res.render('usuarios', {usuarios})
})




module.exports = router