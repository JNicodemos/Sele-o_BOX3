var modal = document.getElementById("userModal");
var btn = document.querySelector(".add-user-button");
var span = document.getElementsByClassName("close")[0];

btn.onclick = function() {
    modal.style.display = "block";
}

span.onclick = function() {
    modal.style.display = "none";
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function toggleAreaLabel() {
    var role = document.getElementById("role").value;
    var area = document.getElementById("area");

    if (role === "funcionario") {
        area.innerHTML = `
            <option value="area1">Área de atuação</option>
            <option value="area2">Área 2</option>
        `;
    } else if (role === "cliente") {
        area.innerHTML = `
            <option value="servico1">Serviço solicitado</option>
            <option value="servico2">Serviço 2</option>
        `;
    }
}

// jquery mascaras

//Mascara CPF
$(document).ready(function(){
  $('#paramCpf').mask('000.000.000-00');
});

// mascara telefone
$("#telefone").mask("(00) 0000-00009");