function showInfo() {
    const infoDiv = document.querySelector('.info');
    const senha = document.getElementById('password').value;

    if (senha === '') {
      infoDiv.style.display = 'none'; // Esconder a div de informações quando o campo está vazio
    } else {
      infoDiv.style.display = 'block'; // Mostrar a div de informações quando o usuário começa a digitar
      verifyPass(); // Chama a função para verificar a senha quando há entrada
    }
  }

  function verifyPass() {
    const senha = document.getElementById('password').value;
    const feed = document.getElementsByClassName('feed');

    const maiuscula = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const number = '0123456789';
    const especial = '@#$%&!';

    let hasLength = senha.length >= 8;
    let hasUpper = false;
    let hasNumber = false;
    let hasSpecial = false;

    // Verificação de cada caractere da senha
    for (let i = 0; i < senha.length; i++) {
      let char = senha.charAt(i);

      if (maiuscula.includes(char)) {
        hasUpper = true;
      } else if (number.includes(char)) {
        hasNumber = true;
      } else if (especial.includes(char)) {
        hasSpecial = true;
      }
    }

    // Atualiza as cores dos feedbacks com base nas verificações
    feed[0].style.color = hasLength ? '#15803d' : '#ff383b';
    feed[1].style.color = hasUpper ? '#15803d' : '#ff383b';
    feed[2].style.color = hasNumber ? '#15803d' : '#ff383b';
    feed[3].style.color = hasSpecial ? '#15803d' : '#ff383b';
  }