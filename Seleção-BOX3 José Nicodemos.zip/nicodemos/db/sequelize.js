const path = require('path')
const { Sequelize } = require("sequelize");

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, './box.db')
})

function connectDatabase() {
  sequelize.authenticate().then(() => console.log('conectado')).catch((e) => console.error(e)) 
}

module.exports = {connectDatabase, sequelize}