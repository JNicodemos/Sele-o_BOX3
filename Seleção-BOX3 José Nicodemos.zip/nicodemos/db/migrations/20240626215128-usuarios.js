"use strict";
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable("usuarios", {
      id: {
        type: Sequelize.TEXT,
        allowNull: true,
        primaryKey: true,
      },
      email: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      cpf: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      telefone: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      nome: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      categoria: {
        type: Sequelize.TEXT,
        allowNull: false,
      },
      senha: {
        type: Sequelize.TEXT,
        allowNull: true,
      },
      status: {
        type: Sequelize.BOOLEAN,
        allowNull: false,
      },
      created_at: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      updated_at: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
    });
    
    // Adicionar índices únicos
    await queryInterface.addIndex("usuarios", ["email"], {
      unique: true,
    });
    await queryInterface.addIndex("usuarios", ["cpf"], {
      unique: true,
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable("usuarios");
  },
};
