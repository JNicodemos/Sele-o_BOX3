'use strict';
const { Model, DataTypes } = require('sequelize');
const bcrypt = require('bcrypt');
const {sequelize} = require('../sequelize')

class Usuario extends Model {
  static associate(models) {
    // Nenhuma associação definida nas migrations fornecidas
  }
}

Usuario.init(
  {
    id: {
      type: DataTypes.TEXT,
      primaryKey: true,
      allowNull: false,
      autoIncrement: true
    },
    nome: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    email: {
      type: DataTypes.TEXT,
      allowNull: false,
      unique: true,
    },
    cpf: {
      type: DataTypes.TEXT,
      allowNull: false,
      unique: true,
    },
    telefone: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    senha: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    categoria: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    status: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
    },
    created_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
    updated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
  },
  {
    sequelize,
    modelName: 'Usuario',
    tableName: 'usuarios',
    timestamps: false, 
  }
);


module.exports = Usuario