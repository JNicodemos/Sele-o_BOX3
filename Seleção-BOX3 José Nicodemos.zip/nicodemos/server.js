const express = require('express');
const path = require('path');
const pages = require('./routes/pages.js');
const actions = require('./routes/actions.js');
const {connectDatabase} = require('./db/sequelize.js');
const { handlebars } = require('hbs');

/*
	Váriaveis de caminhos e de ambiente 
*/

const app = express();
const views_path = path.join(__dirname, 'views'); 
const public_path = path.join(__dirname, 'public'); 
const port = process.env.PORT || 5500;



/*
	Utilização de módulos e configurações do express 
*/

handlebars.registerHelper('ifCond', function(v1, operator, v2, options) {
  switch (operator) {
    case '===':
      return (v1 === v2) ? options.fn(this) : options.inverse(this);
    case '!==':
      return (v1 !== v2) ? options.fn(this) : options.inverse(this);
    case '<':
      return (v1 < v2) ? options.fn(this) : options.inverse(this);
    case '<=':
      return (v1 <= v2) ? options.fn(this) : options.inverse(this);
    case '>':
      return (v1 > v2) ? options.fn(this) : options.inverse(this);
    case '>=':
      return (v1 >= v2) ? options.fn(this) : options.inverse(this);
    default:
      return options.inverse(this);
  }
});


app.use(express.urlencoded({ extended: false }));
app.use(express.static(public_path));
app.set('view engine', 'hbs');
app.set('views', views_path);


/*
	Importação das portas e servidor 
*/

app.use('/', pages);
app.use('/', actions);
app.listen(port, () => {
	console.log(`Servidor rodando http://localhost:${port}`);
	connectDatabase()
});